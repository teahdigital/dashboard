Forked from http://www.eyecon.ro/bootstrap-datepicker/

See documentation [here](http://tarruda.github.com/bootstrap-datetimepicker/).
